class Resources:
    pass
