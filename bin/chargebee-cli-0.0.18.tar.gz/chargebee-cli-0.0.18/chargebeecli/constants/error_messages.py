OPERATION_NOT_SUPPORTED = 'operation is not supported..'
NO_ACTIVE_PROFILE = 'you have not logged in any of the profile'
ACCOUNT_API_NOT_SET = 'account/api_key is not set'
UNABLE_TO_CONNECT_OR_TIMED_OUT = '  Unable to make connection / time out. please chack the hostname or your internet ' \
                                 'connection.'
