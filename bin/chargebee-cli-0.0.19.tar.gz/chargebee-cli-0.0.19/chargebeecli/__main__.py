from chargebeecli.commands import router


def main():
    router.safe_entry_point()


if __name__ == '__main__':
    main()
