class Export_Params:
    def __init__(self, export_format, export_filename, export_path):
        self.export_format = export_format
        self.export_filename = export_filename
        self.export_path = export_path
